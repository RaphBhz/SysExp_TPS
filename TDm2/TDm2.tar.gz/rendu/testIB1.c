#include "gestionProcess.h"

int main() {
    print_pid_ppid("Bonjour");

    return 0;
}